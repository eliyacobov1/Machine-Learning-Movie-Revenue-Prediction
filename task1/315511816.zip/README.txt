file list:

regression.py - this file contain model that predict movies revenue & ranking
movies_dataset.csv - this file includes all the data that the regression model learn